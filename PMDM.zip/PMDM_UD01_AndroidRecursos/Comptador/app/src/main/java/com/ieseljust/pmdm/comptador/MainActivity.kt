package com.ieseljust.pmdm.comptador


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import com.ieseljust.pmdm.comptador.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var contador = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Asigna el valor del contador al TextView
        binding.textView.text = contador.toString()

        // Asigna los comportamientos de los botones
        binding.btAdd.setOnClickListener {
            contador++
            binding.textView.text = contador.toString()
        }

        binding.btResta.setOnClickListener {
            contador--
            binding.textView.text = contador.toString()
        }

        binding.btReset.setOnClickListener {
            contador = 0
            binding.textView.text = contador.toString()
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        // Guarda el estado del contador en el Bundle
        outState.putInt("contador", contador)
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        // Restaura el estado del contador desde el Bundle
        contador = savedInstanceState.getInt("contador")
        binding.textView.text = contador.toString()
    }
}

